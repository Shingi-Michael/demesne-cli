import { useState, useRef, useEffect } from 'react'

type MsgRole = 'user' | 'assistant' | 'thinking'

interface Msg {
  id: number
  role: MsgRole
  content: string
  thinking?: string
  thinkTime?: number
  model?: string
  elapsed?: number
  tokPerSec?: number
  tokens?: string
}

const INITIAL_MSGS: Msg[] = [
  {
    id: 1,
    role: 'user',
    content: 'hey',
  },
  {
    id: 2,
    role: 'assistant',
    thinking: 'User just said "hey". This is a casual greeting. I should respond naturally and confirm readiness.',
    thinkTime: 5.3,
    content: `Hey! I'm ready to help with the demesne-cli project. What would you like to work on — a bug, a feature, some investigation into the codebase?`,
    model: 'qwen3.8-q4_0-100k-b256',
    elapsed: 12.7,
    tokPerSec: 16.2,
    tokens: '2.9k/100k',
  },
  {
    id: 3,
    role: 'user',
    content: 'what can you do?',
  },
  {
    id: 4,
    role: 'assistant',
    thinking: "The user is asking what I can do. Let me give a concise overview of my capabilities. I'm a coding agent inside the demesne-cli project.",
    thinkTime: 3.6,
    content: `I'm a coding agent working in your \`demesne-cli\` project. Here's what I can help with:

**Exploring the codebase**
· List and search files across the repo
· Read and understand code, config, tests, and docs
· Trace how things work (call flows, dependencies, etc.)

**Making changes**
· Writing new code / features
· Fixing bugs (with a test to prove it)
· Refactoring, renaming, cleaning up
· Updating configs, scripts, docs
· Running builds, linters, and tests to verify everything works

**Investigating**
· Reading error messages and stack traces to find root causes
· Comparing behavior, debugging flaky tests, etc.

I work in a loop: inspect first, make targeted edits, then run the relevant commands to confirm the change actually works before reporting back.`,
    model: 'qwen3.8-q4_0-100k-b256',
    elapsed: 18.4,
    tokPerSec: 21.1,
    tokens: '2.9k/100k',
  },
]

function ThinkingBlock({ text, time }: { text: string; time: number }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="thinking-block" style={{ marginBottom: '10px' }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          padding: '0',
          color: 'var(--text-secondary)',
          fontFamily: 'var(--font-mono)',
          fontSize: '11px',
          letterSpacing: '0.04em',
        }}
      >
        <span style={{
          display: 'inline-block',
          width: '6px', height: '6px',
          borderRadius: '50%',
          background: 'var(--amber)',
          boxShadow: '0 0 6px var(--amber)',
        }} />
        <span style={{ color: 'var(--amber)', fontWeight: 500 }}>THINKING</span>
        <span style={{ color: 'var(--text-dim)' }}>·</span>
        <span style={{ color: 'var(--text-dim)' }}>{time}s</span>
        <span style={{ color: 'var(--text-dim)', marginLeft: '4px' }}>{open ? '▲' : '▼'}</span>
      </button>
      {open && (
        <div style={{
          marginTop: '8px',
          padding: '10px 12px',
          background: 'var(--amber-dim)',
          borderLeft: '2px solid var(--amber)',
          color: 'var(--text-secondary)',
          fontSize: '11px',
          lineHeight: '1.7',
          whiteSpace: 'pre-wrap',
        }}>
          {text}
        </div>
      )}
    </div>
  )
}

function renderContent(text: string) {
  const lines = text.split('\n')
  return lines.map((line, i) => {
    const isBold = line.startsWith('**') && line.endsWith('**')
    const isBullet = line.startsWith('·') || line.startsWith('•')
    const isCode = line.includes('`')

    if (isBold) {
      return (
        <div key={i} style={{ color: 'var(--cyan)', fontWeight: 600, marginTop: i > 0 ? '14px' : 0, marginBottom: '4px', fontSize: '11px', letterSpacing: '0.06em' }}>
          {line.replace(/\*\*/g, '')}
        </div>
      )
    }
    if (isBullet) {
      return (
        <div key={i} style={{ paddingLeft: '16px', color: 'var(--text-primary)', position: 'relative' }}>
          <span style={{ position: 'absolute', left: 0, color: 'var(--text-dim)' }}>·</span>
          {line.slice(1).trim()}
        </div>
      )
    }
    if (isCode) {
      const parts = line.split('`')
      return (
        <div key={i}>
          {parts.map((p, j) =>
            j % 2 === 1 ? (
              <code key={j} style={{
                background: 'var(--bg-3)',
                color: 'var(--cyan)',
                padding: '1px 5px',
                border: '1px solid var(--border)',
                fontSize: '11px',
              }}>{p}</code>
            ) : <span key={j}>{p}</span>
          )}
        </div>
      )
    }
    return <div key={i} style={{ minHeight: line === '' ? '8px' : undefined }}>{line}</div>
  })
}

function AssistantMsg({ msg, idx }: { msg: Msg; idx: number }) {
  return (
    <div className="msg-in" style={{ animationDelay: `${idx * 0.05}s`, opacity: 0 }}>
      {msg.thinking && <ThinkingBlock text={msg.thinking} time={msg.thinkTime!} />}
      <div style={{
        color: 'var(--text-primary)',
        lineHeight: '1.75',
        fontSize: '13px',
      }}>
        {renderContent(msg.content)}
      </div>
      {msg.model && (
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginTop: '14px',
          paddingTop: '10px',
          borderTop: '1px solid var(--border)',
          color: 'var(--text-dim)',
          fontSize: '11px',
          letterSpacing: '0.03em',
        }}>
          <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
            <span style={{ color: 'var(--text-secondary)' }}>{msg.model}</span>
            <Divider />
            <Stat label="elapsed" value={`${msg.elapsed}s`} />
            <Divider />
            <Stat label="speed" value={`${msg.tokPerSec} tok/s`} accent />
            <Divider />
            <Stat label="ctx" value={msg.tokens!} />
          </div>
          <button style={{
            background: 'none',
            border: '1px solid var(--border)',
            color: 'var(--text-secondary)',
            fontFamily: 'var(--font-mono)',
            fontSize: '10px',
            padding: '2px 8px',
            cursor: 'pointer',
            letterSpacing: '0.08em',
            transition: 'border-color 0.15s, color 0.15s',
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--cyan)'
            ;(e.currentTarget as HTMLButtonElement).style.color = 'var(--cyan)'
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border)'
            ;(e.currentTarget as HTMLButtonElement).style.color = 'var(--text-secondary)'
          }}
          >COPY</button>
        </div>
      )}
    </div>
  )
}

function Divider() {
  return <span style={{ color: 'var(--border-bright)' }}>·</span>
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <span>
      <span style={{ color: 'var(--text-dim)' }}>{label} </span>
      <span style={{ color: accent ? 'var(--green)' : 'var(--text-secondary)' }}>{value}</span>
    </span>
  )
}

// Hook this to open the panel: call openPanel(content) from any action handler
// e.g. tool-use results, file diffs, artifact previews, etc.
function useSidePanel() {
  const [panel, setPanel] = useState<{ type: string; content: string } | null>(null)
  const open = (type: string, content: string) => setPanel({ type, content })
  const close = () => setPanel(null)
  return { panel, open, close }
}

export default function App() {
const [input, setInput] = useState('')
  const [msgs, setMsgs] = useState<Msg[]>(INITIAL_MSGS)
  const [thinking, setThinking] = useState(false)
  const { panel, open: openPanel, close: closePanel } = useSidePanel()
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [msgs, thinking])

  function send() {
    const text = input.trim()
    if (!text) return
    const userMsg: Msg = { id: Date.now(), role: 'user', content: text }
    setMsgs(m => [...m, userMsg])
    setInput('')
    setThinking(true)
    setTimeout(() => {
      setThinking(false)
      const reply: Msg = {
        id: Date.now() + 1,
        role: 'assistant',
        thinking: 'Processing request and formulating response...',
        thinkTime: +(Math.random() * 4 + 1).toFixed(1),
        content: `I received: "${text}"\n\nThis is a harness UI mockup — connect me to a live agent to get real responses.`,
        model: 'qwen3.8-q4_0-100k-b256',
        elapsed: +(Math.random() * 15 + 5).toFixed(1),
        tokPerSec: +(Math.random() * 20 + 10).toFixed(1),
        tokens: '3.1k/100k',
      }
      setMsgs(m => [...m, reply])
    }, 2200)
  }

  return (
    <div style={{
      display: 'flex',
      height: '100vh',
      background: 'var(--bg)',
      overflow: 'hidden',
    }}>
    {/* Left: terminal column */}
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      flex: 1,
      minWidth: 0,
      overflow: 'hidden',
    }}>


      {/* Session Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '10px 20px',
        borderBottom: '1px solid var(--border)',
        background: 'var(--bg-2)',
        position: 'relative',
        zIndex: 2,
        flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <span style={{ color: 'var(--cyan)', fontWeight: 700, letterSpacing: '0.02em' }}>// demesne</span>
          <span style={{ color: 'var(--text-dim)' }}>Session</span>
          <span style={{ color: 'var(--text-secondary)' }}>7:03:38 PM</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', color: 'var(--text-dim)', fontSize: '11px' }}>
          <span style={{ color: 'var(--text-secondary)' }}>~/projects/demesne-cli</span>
          <button style={{
            background: 'none',
            border: '1px solid var(--border)',
            color: 'var(--text-secondary)',
            fontFamily: 'var(--font-mono)',
            fontSize: '11px',
            padding: '2px 10px',
            cursor: 'pointer',
            letterSpacing: '0.06em',
            transition: 'all 0.15s',
          }}
          onMouseEnter={e => {
            const el = e.currentTarget as HTMLButtonElement
            el.style.borderColor = 'var(--cyan)'
            el.style.color = 'var(--cyan)'
          }}
          onMouseLeave={e => {
            const el = e.currentTarget as HTMLButtonElement
            el.style.borderColor = 'var(--border)'
            el.style.color = 'var(--text-secondary)'
          }}
          >HISTORY ↓</button>
        </div>
      </div>

      {/* Message Stream */}
      <div
        ref={scrollRef}
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: '20px 24px',
          position: 'relative',
          zIndex: 1,
        }}
      >
        {msgs.map((msg, idx) => (
          <div key={msg.id} style={{ marginBottom: '24px' }}>
            {msg.role === 'user' ? (
              <div className="msg-in" style={{ animationDelay: `${idx * 0.03}s`, opacity: 0 }}>
                <div style={{
                  display: 'flex',
                  gap: '12px',
                  alignItems: 'flex-start',
                  background: 'linear-gradient(90deg, rgba(0,212,255,0.06) 0%, transparent 80%)',
                  borderLeft: '2px solid var(--cyan)',
                  padding: '8px 12px',
                  marginLeft: '-14px',
                }}>
                  <span style={{
                    color: 'var(--cyan)',
                    fontWeight: 700,
                    flexShrink: 0,
                    marginTop: '1px',
                  }}>▶</span>
                  <div style={{
                    color: 'var(--text-primary)',
                    fontWeight: 500,
                    fontSize: '13px',
                  }}>{msg.content}</div>
                </div>
              </div>
            ) : (
              <div style={{
                marginLeft: '24px',
                padding: '16px 18px',
                background: 'var(--bg-2)',
                border: '1px solid var(--border)',
                position: 'relative',
              }}>
                {/* Corner brackets */}
                <div style={{
                  position: 'absolute',
                  top: 0, left: 0,
                  width: '10px', height: '10px',
                  borderTop: '1px solid var(--cyan)',
                  borderLeft: '1px solid var(--cyan)',
                }} />
                <div style={{
                  position: 'absolute',
                  bottom: 0, right: 0,
                  width: '10px', height: '10px',
                  borderBottom: '1px solid var(--cyan)',
                  borderRight: '1px solid var(--cyan)',
                }} />
                <AssistantMsg msg={msg} idx={idx} />
              </div>
            )}
          </div>
        ))}

        {/* Live thinking indicator */}
        {thinking && (
          <div style={{ marginLeft: '24px', marginBottom: '24px' }}>
            <div style={{
              padding: '14px 18px',
              background: 'var(--bg-2)',
              border: '1px solid var(--border)',
              borderLeft: '2px solid var(--amber)',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
            }}>
              <div style={{ display: 'flex', gap: '4px' }}>
                {[0, 1, 2].map(i => (
                  <span key={i} className="thinking-dot" style={{
                    display: 'inline-block',
                    width: '5px', height: '5px',
                    borderRadius: '50%',
                    background: 'var(--amber)',
                    animationDelay: `${i * 0.2}s`,
                  }} />
                ))}
              </div>
              <span style={{ color: 'var(--amber)', fontSize: '11px', letterSpacing: '0.06em', fontWeight: 500 }}>THINKING</span>
            </div>
          </div>
        )}
      </div>

      {/* Input + Status Bar */}
      <div style={{
        borderTop: '1px solid var(--border)',
        background: 'var(--bg-2)',
        position: 'relative',
        zIndex: 2,
        flexShrink: 0,
      }}>
        {/* Input area */}
        <div style={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '10px',
          padding: '12px 20px',
          borderBottom: '1px solid var(--border)',
        }}>
          <span style={{ color: 'var(--cyan)', fontWeight: 700, paddingTop: '2px', flexShrink: 0 }}>▶</span>
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                send()
              }
            }}
            placeholder="Continue the conversation..."
            rows={1}
            style={{
              flex: 1,
              background: 'none',
              border: 'none',
              outline: 'none',
              color: 'var(--text-primary)',
              fontFamily: 'var(--font-mono)',
              fontSize: '13px',
              resize: 'none',
              lineHeight: '1.6',
              caretColor: 'var(--cyan)',
              minHeight: '22px',
              maxHeight: '120px',
              overflow: 'auto',
            }}
          />
          <button
            onClick={send}
            disabled={thinking || !input.trim()}
            style={{
              background: 'none',
              border: `1px solid ${thinking || !input.trim() ? 'var(--border)' : 'var(--cyan)'}`,
              color: thinking || !input.trim() ? 'var(--text-dim)' : 'var(--cyan)',
              fontFamily: 'var(--font-mono)',
              fontSize: '10px',
              padding: '4px 10px',
              cursor: thinking || !input.trim() ? 'default' : 'pointer',
              letterSpacing: '0.08em',
              transition: 'all 0.15s',
              flexShrink: 0,
            }}
          >SEND ↵</button>
        </div>

        {/* Status bar */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '6px 20px',
          fontSize: '10px',
          letterSpacing: '0.04em',
          color: 'var(--text-secondary)',
        }}>
          <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
            <StatusItem icon="↑" label="SCROLLBACK" />
            <span style={{ color: 'var(--border-bright)' }}>·</span>
            <StatusItem color="var(--green)" label="COMPLETE" icon="✓" />
          </div>
          <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
            <span>
              <span style={{ color: 'var(--text-dim)' }}>ctx </span>
              <span style={{ color: 'var(--amber)' }}>~2.9k/100k</span>
              <span style={{ color: 'var(--text-dim)' }}> · 3%</span>
            </span>
            <span style={{ color: 'var(--border-bright)' }}>·</span>
            <StatusItem label="RESPONSE ↑" />
            <span style={{ color: 'var(--border-bright)' }}>·</span>
            <StatusItem label="Ctrl+G LIVE ↓" />
          </div>
        </div>
      </div>
    </div>{/* end terminal column */}

    {/* Right: reserved panel */}
    <RightPanel panel={panel} onClose={closePanel} onDemoOpen={() => openPanel('preview', 'Panel triggered by action.')} />

    </div>
  )
}

function RightPanel({
  panel,
  onClose,
  onDemoOpen,
}: {
  panel: { type: string; content: string } | null
  onClose: () => void
  onDemoOpen: () => void
}) {
  return (
    <div style={{
      width: panel ? '340px' : '48px',
      flexShrink: 0,
      borderLeft: '1px solid var(--border)',
      display: 'flex',
      flexDirection: 'column',
      transition: 'width 0.22s cubic-bezier(0.4, 0, 0.2, 1)',
      overflow: 'hidden',
      background: 'var(--bg-2)',
      position: 'relative',
    }}>
      {/* Collapsed rail */}
      {!panel && (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          paddingTop: '16px',
          gap: '20px',
          width: '48px',
        }}>
          {/* Reserved indicator */}
          <div style={{
            width: '2px',
            height: '24px',
            background: 'var(--border-bright)',
            borderRadius: '1px',
            opacity: 0.5,
          }} />
          {/* Demo trigger — wire this to real actions */}
          <button
            title="Open panel (demo)"
            onClick={onDemoOpen}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '4px',
              color: 'var(--text-dim)',
              transition: 'color 0.15s',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.color = 'var(--cyan)'}
            onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-dim)'}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <rect x="1" y="1" width="14" height="14" rx="0" stroke="currentColor" strokeWidth="1" strokeDasharray="2 2"/>
              <line x1="8" y1="4" x2="8" y2="12" stroke="currentColor" strokeWidth="1"/>
              <line x1="4" y1="8" x2="12" y2="8" stroke="currentColor" strokeWidth="1"/>
            </svg>
          </button>
        </div>
      )}

      {/* Expanded panel content */}
      {panel && (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          height: '100%',
          width: '340px',
        }}>
          {/* Panel header */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '10px 16px',
            borderBottom: '1px solid var(--border)',
            flexShrink: 0,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{
                display: 'inline-block',
                width: '6px', height: '6px',
                background: 'var(--cyan)',
                boxShadow: '0 0 6px var(--cyan)',
              }} />
              <span style={{
                color: 'var(--cyan)',
                fontSize: '10px',
                letterSpacing: '0.1em',
                fontWeight: 600,
              }}>{panel.type.toUpperCase()}</span>
            </div>
            <button
              onClick={onClose}
              style={{
                background: 'none',
                border: 'none',
                color: 'var(--text-dim)',
                cursor: 'pointer',
                fontFamily: 'var(--font-mono)',
                fontSize: '12px',
                padding: '2px 6px',
                transition: 'color 0.15s',
              }}
              onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-primary)'}
              onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-dim)'}
            >✕</button>
          </div>

          {/* Panel body — future feature fills here */}
          <div style={{
            flex: 1,
            overflow: 'auto',
            padding: '20px 16px',
            display: 'flex',
            flexDirection: 'column',
            gap: '16px',
          }}>
            <div style={{
              border: '1px dashed var(--border-bright)',
              padding: '24px 16px',
              textAlign: 'center',
              color: 'var(--text-dim)',
              fontSize: '11px',
              letterSpacing: '0.06em',
              lineHeight: '1.8',
            }}>
              <div style={{ color: 'var(--text-secondary)', marginBottom: '8px' }}>RESERVED</div>
              <div>Future feature surface</div>
              <div style={{ marginTop: '8px', color: 'var(--border-bright)' }}>
                · file diffs<br/>
                · tool outputs<br/>
                · artifact previews<br/>
                · context viewer
              </div>
            </div>
            <div style={{
              padding: '12px',
              background: 'var(--bg-3)',
              border: '1px solid var(--border)',
              fontSize: '11px',
              color: 'var(--text-secondary)',
            }}>
              <span style={{ color: 'var(--text-dim)' }}>triggered by </span>
              <span style={{ color: 'var(--amber)' }}>{panel.type}</span>
              <div style={{ marginTop: '8px', color: 'var(--text-dim)', wordBreak: 'break-word' }}>{panel.content}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function StatusItem({ icon, label, color }: { icon?: string; label: string; color?: string }) {
  return (
    <span style={{ display: 'flex', alignItems: 'center', gap: '4px', color: color || 'var(--text-dim)' }}>
      {icon && <span>{icon}</span>}
      <span style={{ letterSpacing: '0.06em' }}>{label}</span>
    </span>
  )
}
